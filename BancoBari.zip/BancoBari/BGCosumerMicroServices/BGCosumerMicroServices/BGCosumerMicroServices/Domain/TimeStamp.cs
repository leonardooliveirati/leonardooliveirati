﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BGCosumerMicroServices.Domain
{
    public class TimeStamp
    {
        public string Name { get; set; }

        public string Identificador { get; set; }

        public string Stamp { get; set; }
    }
}
