﻿using BGCosumerMicroServices.Domain;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace BGCosumerMicroServices.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class CosumerController : ControllerBase
    {
        private readonly ILogger<CosumerController> _logger;

        public CosumerController(ILogger<CosumerController> logger)
        {
            _logger = logger;
        }

        [HttpGet]
        public ActionResult Get()
        {           
            var timeStamp = new TimeStamp() { };
            var factory = new ConnectionFactory() { HostName = "localhost" };
            using (var connection = factory.CreateConnection())
            using (var channel = connection.CreateModel())
            {
                channel.QueueDeclare(queue: "producerQueue",
                                     durable: false,
                                     exclusive: false,
                                     autoDelete: false,
                                     arguments: null);

                var consumer = new EventingBasicConsumer(channel);
                consumer.Received += (model, ea) =>
                {
                    var body = ea.Body.ToArray();
                    var message = Encoding.UTF8.GetString(body);

                    timeStamp = JsonSerializer.Deserialize<TimeStamp>(message);
                };
                channel.BasicConsume(queue: "producerQueue",
                                     autoAck: true,
                                     consumer: consumer);

                return Ok(timeStamp);
            }
        }
    }
}
