﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BGProducerMicroServices.Domain
{
    public class TimeStamp
    {
        public string Name { get; set; }

        public string Identificador { get; set; }

        public string Stamp { get; set; }
    }
}
