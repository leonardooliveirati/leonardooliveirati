﻿using BGProducerMicroServices.Domain;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using RabbitMQ.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace BGProducerMicroServices.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class ProducerController : ControllerBase
    {
        private readonly ILogger<ProducerController> _logger;

        public ProducerController(ILogger<ProducerController> logger)
        {
            _logger = logger;
        }

        [HttpPost]
        public ActionResult Post()
        {
            try
            {
                TimeStamp timeStamp = new TimeStamp { 
                    Name = "Hello World!", 
                    Stamp = DateTime.Now.ToString("hhmmssfff"), 
                    Identificador = Guid.NewGuid().ToString() };

                var factory = new ConnectionFactory() { HostName = "localhost" };
                using (var connection = factory.CreateConnection())
                using (var channel = connection.CreateModel())
                {
                    channel.QueueDeclare(queue: "producerQueue",
                                         durable: false,
                                         exclusive: false,
                                         autoDelete: false,
                                         arguments: null);

                    string message = JsonSerializer.Serialize(timeStamp);
                    var body = Encoding.UTF8.GetBytes(message);

                    channel.BasicPublish(exchange: "",
                                         routingKey: "producerQueue",
                                         basicProperties: null,
                                         body: body);                    
                }

                return Ok(timeStamp);
            }
            catch (Exception ex)
            {
                _logger.LogError("Erro ao tentar criar mensagem: ", ex.Message);

                return new StatusCodeResult(500);
            }
        }
    }
}
